import Home from "./pages/Home";
import "./App.css";
import DotGrid from "./components/DotGrid";

function App() {
  return (
    <div className="relative min-h-screen bg-black">
      
     
      {/* Website content */}
      <div className="relative z-10">
        <Home />
      </div>

    </div>
  );
}
export default App;