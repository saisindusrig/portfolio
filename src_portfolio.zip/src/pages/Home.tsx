import Navbar from "../components/Navbar";
import ProjectCard from "../components/ProjectCard";
import { projects } from "../data/projects";
import Skills from "../components/Skills";
import Contact from "../components/Contact";

const Home = () => {
  return (
    <main className="min-h-screen w-full">
      <Navbar />

      <div className="mx-auto w-full max-w-5xl px-5 sm:px-8 lg:px-10">
        {/* ================================
            ABOUT / HERO
        ================================= */}
        <section
          id="about"
          className="
            flex
            min-h-[70vh]
            scroll-mt-32
            flex-col
            justify-center
            py-24
            sm:py-32
          "
        >
          <div className="max-w-3xl">
            <p
              className="
                font-body
                font-bold
                text-7xl
                text-center
                py-20
              "
            >
              I'm Sindu
            </p>

            <p
              className="
                text-3xl
                text-center
                sm:text-base
                sm:leading-8
              "
            >
              I'm a full-stack developer with 1+ year of professional
              experience building web applications. I enjoy working
              across the stack, from designing responsive React
              interfaces to building APIs, authentication systems and
              database-driven features.
            </p>
          </div>
        </section>

        {/* ================================
            PROJECTS
        ================================= */}
        <section
          id="projects"
          className="
            scroll-mt-32
            py-20
            sm:py-24
          "
        >
          {/* SECTION HEADING */}
          <div className="mb-8">
            <h2
              className="
                font-heading
                text-2xl
                font-semibold
                tracking-tight
                sm:text-3xl
              "
            >
              projects
            </h2>

            <p className="mt-2 text-sm text-white/40">
              A selection of things I've built.
            </p>
          </div>

          {/* PROJECT LIST */}
          <div className="flex w-full flex-col gap-6">
            {projects.map((project) => (
              <ProjectCard
                key={project.title}
                project={project}
              />
            ))}
          </div>
        </section>

        {/* ================================
            SKILLS
        ================================= */}
        <section
          id="skills"
          className="
            scroll-mt-32
            py-20
            sm:py-24
          "
        >
          {/* SECTION HEADING */}
          <div className="mb-8">
            <h2
              className="
                font-heading
                text-2xl
                font-semibold
                tracking-tight
                sm:text-3xl
              "
            >
              skills
            </h2>

            <p className="mt-2 text-sm text-white/40">
              Technologies I work with.
            </p>
          </div>

          <Skills />
        </section>

        {/* ================================
            CONTACT
        ================================= */}
        <section
          id="contact"
          className="
            scroll-mt-32
            py-20
            pb-32
            sm:py-24
            sm:pb-40
          "
        >
          {/* SECTION HEADING */}
          <div className="mb-8">
            <h2
              className="
                font-heading
                text-2xl
                font-semibold
                tracking-tight
                sm:text-3xl
              "
            >
              contact
            </h2>

            <p className="mt-2 text-sm text-white/40">
              Have a project in mind? Let's talk.
            </p>
          </div>

          <Contact />
        </section>
      </div>
    </main>
  );
};

export default Home;