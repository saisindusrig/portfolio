import type { Project } from "../data/projects";
import { FaGithub } from "react-icons/fa";

interface ProjectCardProps {
  project: Project;
}

const ProjectCard = ({ project }: ProjectCardProps) => {
  return (
    <article
      className="
        glass-card
        group
        flex
        w-full
        min-h-[220px]
        overflow-hidden
        rounded-2xl
      "
    >
      {/* PROJECT IMAGE */}
      <div
        className="
          relative
          w-[38%]
          min-w-[240px]
          overflow-hidden
          bg-[#eeeeee]
        "
      >
        <img
          src={project.image}
          alt={`${project.title} screenshot`}
          className="
            h-full
            w-full
            object-cover
            transition-transform
            duration-500
            group-hover:scale-[1.03]
          "
        />
      </div>

      {/* CARD CONTENT */}
      <div
        className="
          flex
          flex-1
          flex-col
          justify-between
          p-6
        "
      >
        {/* TOP CONTENT */}
        <div>
          {/* TITLE + LINKS */}
          <div
            className="
              flex
              items-start
              justify-between
              gap-4
            "
          >
            <h3
              className="
                font-heading
                text-lg
                font-medium
                tracking-tight
              "
            >
              {project.title}
            </h3>

            {/* LINKS */}
            <div
              className="
                flex
                shrink-0
                items-center
                gap-4
              "
            >
              <a
                href={project.github}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`${project.title} GitHub`}
                className="
                  opacity-50
                  transition-all
                  duration-200
                  hover:scale-110
                  hover:opacity-100
                "
              >
                <FaGithub size={19} />
              </a>

              <a
                href={project.live}
                target="_blank"
                rel="noopener noreferrer"
                className="
                  text-xs
                  opacity-50
                  transition-opacity
                  duration-200
                  hover:opacity-100
                "
              >
                View ↗
              </a>
            </div>
          </div>

          {/* DESCRIPTION */}
          <p
            className="
              mt-3
              max-w-2xl
              text-sm
              leading-6
              opacity-55
            "
          >
            {project.description}
          </p>
        </div>

        {/* BOTTOM CONTENT */}
        <div className="mt-6">
          {/* TECH STACK */}
          <div className="flex flex-wrap gap-2">
            {project.tech.map((tech) => (
              <span
                key={tech}
                className="
                  glass-badge
                  text-xs
                "
              >
                {tech}
              </span>
            ))}
          </div>
        </div>
      </div>
    </article>
  );
};

export default ProjectCard;